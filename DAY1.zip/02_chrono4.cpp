#include <iostream>
#include <chrono>
#include <string>

int main()
{
    std::chrono::system_clock::time_point tp =
                                std::chrono::system_clock::now();

    std::chrono::nanoseconds ns = tp.time_since_epoch();

    std::cout << ns.count() << std::endl;
}