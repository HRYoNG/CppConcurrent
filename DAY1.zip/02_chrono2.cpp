#include <iostream>
#include <chrono>

int main()
{
	std::chrono::seconds s = 70;


	std::chrono::nanoseconds n = s;

	std::chrono::minutes m = s;

}
